package controller;

import dao.PhieumuahangDAO;
import poly.cafe.entity.PMHModel;
import poly.cafe.entity.Sanpham;
import poly.cafe.entity.ChiTietPhieuMuaHangModel;
import java.util.ArrayList;
import java.util.List;

public class PhieuMuaHangController {
    private PhieumuahangDAO dao = new PhieumuahangDAO();

    public List<Sanpham> getAllSanpham() {
        return dao.getAll();
    }

    public void savePhieuMuaHang(PMHModel pmh, List<Sanpham> sanphams) {
        dao.insertPhieu(pmh);
        for (Sanpham sp : sanphams) {
            ChiTietPhieuMuaHangModel ctpmh = new ChiTietPhieuMuaHangModel(pmh.getMaHD(), sp.getMASP(), sp.getSoLuong(), sp.getGIA(), sp.getTENSP(), sp.getLOAISP());
            dao.insertChiTietPhieu(ctpmh);
        }
    }

    public PMHModel getPMHByID(String maPMH) {
        return dao.getPMHByID(maPMH);
    }

    public List<ChiTietPhieuMuaHangModel> getChiTietByMaPMH(String maPMH) {
        return dao.getChiTietByMaPMH(maPMH);
    }

    public void updatePhieuMuaHang(PMHModel pmh, List<Sanpham> sanphams) {
        dao.updatePhieu(pmh);
        dao.deleteChiTietPhieu(pmh.getMaHD());
        for (Sanpham sp : sanphams) {
            ChiTietPhieuMuaHangModel ctpmh = new ChiTietPhieuMuaHangModel(pmh.getMaHD(), sp.getMASP(), sp.getSoLuong(), sp.getGIA(), sp.getTENSP(), sp.getLOAISP());
            dao.insertChiTietPhieu(ctpmh);
        }
    }

    public void exportToPDF(PMHModel pmh, List<Sanpham> sanphams) {
        // Logic xuất hóa đơn PDF
    }
}
