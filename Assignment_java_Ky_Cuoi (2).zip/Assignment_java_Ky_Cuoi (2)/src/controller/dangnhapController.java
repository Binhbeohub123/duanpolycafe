package controller;

import dao.dangnhapDAO;

public class dangnhapController {

    private dangnhapDAO dao;
    private int lanDangNhap = 0;
    private static final int gioiHanLanDangNhap = 5;

    public dangnhapController() {
        this.dao = new dangnhapDAO();
    }

    public String login(String TaiKhoanID, String Matkhau) {
        if (lanDangNhap >= gioiHanLanDangNhap) {
            throw new RuntimeException("Tài khoản đã bị khóa do nhập sai quá nhiều lần!");
        }

        if (isBlank(TaiKhoanID) || isBlank(Matkhau)) {
            return null;
        }

        String role = dao.getRole(TaiKhoanID, Matkhau);
        if (role == null) {
            lanDangNhap++;
        } else {
            lanDangNhap = 0;
        }
        return role;
    }

    // ✅ Hàm xử lý chuỗi viết trực tiếp trong controller
    private boolean isBlank(String str) {
        return str == null || str.trim().isEmpty();
    }
}
