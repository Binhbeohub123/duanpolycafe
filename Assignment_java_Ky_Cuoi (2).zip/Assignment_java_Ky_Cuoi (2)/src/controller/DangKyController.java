/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.DangkyDao;
import dao.thaydoimatkhauDAO;
import giaodien.MaXacNhan;
import giaodien.dangkyform;
import javax.swing.JOptionPane;
import otpRandom.guiMailMaOTP;
import giaodien.dangNhap;
import poly.cafe.entity.PendingAccount;

/**
 *
 * @author acchi
 */
public class DangKyController {
    private final DangkyDao dao;
    private dangkyform view;

    public DangKyController(dangkyform view) {
        this.view = view;
        this.dao = new DangkyDao();
    }
    public DangKyController() {
        this.view = view;
        this.dao = new DangkyDao();
    }
    
    public boolean insertPendingAccount(PendingAccount acc) {
    PendingAccount existing = DangkyDao.findByEmail(acc.getEmail());
    if (existing != null) {
        // Xóa bản ghi pending cũ
        DangkyDao.deleteByEmail(acc.getEmail());
    }
    // Chèn bản ghi mới
    DangkyDao.insertPending(acc);
    return true;
}
    
    public PendingAccount getPendingAccountByEmail(String email) {
        return DangkyDao.findByEmail(email);
    }
    public String getFullnameFromPending(String email) {
    return DangkyDao.getTenByEmail(email);
}
    public boolean confirmRegistration(String email) {
        try {
            PendingAccount acc = DangkyDao.findByEmail(email);
            if (acc != null) {
                DangkyDao dao = new DangkyDao();
                boolean inserted = dao.Insert(email, acc.getPassword(), acc.getEmail());
                if (inserted) {
                    DangkyDao.deleteByEmail(email);
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            System.err.println("Lỗi confirmRegistration: " + e.getMessage());
            return false;
        }
    }


    public String validateUserInput(String taikhoanID, String matKhau, String xacNhanMatKhau, String email) {
        if (taikhoanID == null || taikhoanID.trim().isEmpty()) {
            return "Tên tài khoản không được để trống!";
        }
        if (email == null || email.trim().isEmpty() || !email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            return "Email không hợp lệ!";
        }
        if (matKhau == null || matKhau.trim().isEmpty()) {
            return "Mật khẩu không được để trống!";
        }
        if (!matKhau.equals(xacNhanMatKhau)) {
            return "Mật khẩu xác nhận không khớp!";
        }
        return null; // Dữ liệu hợp lệ
    }


    public void registerUser(String taikhoanID, String matKhau, String xacNhanMatKhau, String email) {
        // Kiểm tra dữ liệu đầu vào
        String validationError = validateUserInput(taikhoanID, matKhau, xacNhanMatKhau, email);
        if (validationError != null) {
            JOptionPane.showMessageDialog(null, validationError, "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Kiểm tra email đã tồn tại chưa
        if (dao.CheckUserExist(email)) {
            JOptionPane.showMessageDialog(null, "Email đã được sử dụng!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Thêm người dùng mới
        boolean success = dao.Insert(taikhoanID, matKhau, email);
        if (success) {
            JOptionPane.showMessageDialog(null, "Đăng ký thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Đăng ký thất bại! Vui lòng thử lại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
    public void backToLogin() {
        if (view.getParentFrame().getPanelGoc() != null) {
            view.getParentFrame().setContentPane(view.getParentFrame().getPanelGoc());
            view.getParentFrame().revalidate();
            view.getParentFrame().repaint();
        } else {
            JOptionPane.showMessageDialog(view, "Không thể tải giao diện đăng nhập!");
        }
    }

}