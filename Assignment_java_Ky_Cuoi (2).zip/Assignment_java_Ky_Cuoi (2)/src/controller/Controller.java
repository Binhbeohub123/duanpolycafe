package controller;

import dao.THEDAO;
import poly.cafe.entity.Model;
import java.util.List;

public class Controller {
    private THEDAO theDAO = new THEDAO();

    public List<Model> getAllThe() {
        return theDAO.getAllThe();
    }

    public boolean capNhatThe(Model model) {
        return theDAO.capNhatThe(model);
    }
    public Model getTheByMaThe(String maThe) {
    THEDAO theDAO = new THEDAO();
    return theDAO.getTheByMaThe(maThe);
}
}
