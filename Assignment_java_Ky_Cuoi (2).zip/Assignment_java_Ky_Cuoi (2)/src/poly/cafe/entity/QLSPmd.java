/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poly.cafe.entity;

/**
 *
 * @author ADMIN
 */
public class QLSPmd {
    private String MASP;
    private String TENSP;
    private String LOAISP;
    private double GIA;

    public QLSPmd() {
    }

    public QLSPmd(String MASP, String TENSP, String LOAISP, double GIA) {
        this.MASP = MASP;
        this.TENSP = TENSP;
        this.LOAISP = LOAISP;
        this.GIA = GIA;
    }

    public String getMASP() {
        return MASP;
    }

    public void setMASP(String MASP) {
        this.MASP = MASP;
    }

    public String getTENSP() {
        return TENSP;
    }

    public void setTENSP(String TENSP) {
        this.TENSP = TENSP;
    }

    public String getLOAISP() {
        return LOAISP;
    }

    public void setLOAISP(String LOAISP) {
        this.LOAISP = LOAISP;
    }

    public double getGIA() {
        return GIA;
    }

    public void setGIA(double GIA) {
        this.GIA = GIA;
    }

    
    
}
