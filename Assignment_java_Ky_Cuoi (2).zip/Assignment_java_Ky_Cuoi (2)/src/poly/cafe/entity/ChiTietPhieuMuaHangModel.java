package poly.cafe.entity;

public class ChiTietPhieuMuaHangModel {
    private String maHD;
    private String maSP;
    private int soLuong;
    private double gia;
    private String tenSP;
    private String loaiSP;

    // Constructor mặc định
    public ChiTietPhieuMuaHangModel() {
    }

    // Constructor đầy đủ tham số
    public ChiTietPhieuMuaHangModel(String maHD, String maSP, int soLuong, double gia, String tenSP, String loaiSP) {
        this.maHD = maHD;
        this.maSP = maSP;
        this.soLuong = soLuong;
        this.gia = gia;
        this.tenSP = tenSP;
        this.loaiSP = loaiSP;
    }

    // Getter và Setter
    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getGia() {
        return gia;
    }

    public void setGia(double gia) {
        this.gia = gia;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public String getLoaiSP() {
        return loaiSP;
    }

    public void setLoaiSP(String loaiSP) {
        this.loaiSP = loaiSP;
    }
}