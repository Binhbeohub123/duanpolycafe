/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.cafe.entity;

/**
 *
 * @author ASUS
 */
public class Sanpham {
   private String MASP;
    private String TENSP;
    private String LOAISP;
    private double GIA; 
    private int SoLuong;

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int SoLuong) {
        this.SoLuong = SoLuong;
    }
    

    public Sanpham() {
    }

    public Sanpham(String MASP, String TENSP, String LOAISP, double GIA, int SoLuong) {
        this.MASP = MASP;
        this.TENSP = TENSP;
        this.LOAISP = LOAISP;
        this.GIA = GIA;
        this.SoLuong = SoLuong;
    }

    public String getMASP() {
        return MASP;
    }

    public void setMASP(String MASP) {
        this.MASP = MASP;
    }

    public String getTENSP() {
        return TENSP;
    }

    public void setTENSP(String TENSP) {
        this.TENSP = TENSP;
    }

    public String getLOAISP() {
        return LOAISP;
    }

    public void setLOAISP(String LOAISP) {
        this.LOAISP = LOAISP;
    }

    public double getGIA() {
        return GIA;
    }

    public void setGIA(double GIA) {
        this.GIA = GIA;
    }

    public Object[] toRow() {
        return new Object[]{this.MASP, this.TENSP, this.LOAISP, this.GIA};
    }
}