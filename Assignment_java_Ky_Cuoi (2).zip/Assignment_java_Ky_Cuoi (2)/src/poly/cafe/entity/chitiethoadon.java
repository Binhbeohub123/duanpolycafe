/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.cafe.entity;

/**
 *
 * @author ASUS
 */
public class chitiethoadon {
    private String idBills;
    private String idSP;

    public chitiethoadon(String idBills, String idSP) {
        this.idBills = idBills;
        this.idSP = idSP;
    }

    public String getIdBills() {
        return idBills;
    }

    public void setIdBills(String idBills) {
        this.idBills = idBills;
    }

    public String getIdSP() {
        return idSP;
    }

    public void setIdSP(String idSP) {
        this.idSP = idSP;
    }
    
}
