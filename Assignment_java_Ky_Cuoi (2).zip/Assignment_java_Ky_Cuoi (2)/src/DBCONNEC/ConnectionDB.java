package DBCONNEC;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionDB {
    private static final String dbUrl = "jdbc:sqlserver://localhost:1433;databasename=QLDThu;trustServerCertificate=true";
    private static final String username = "sa";
    private static final String password = "sa";

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(dbUrl, username, password);
    }
}

