package DBCONNEC;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    private static String dbUrl = "jdbc:sqlserver://localhost:1433;databasename=QLSP1;trustServerCertificate=true";
    private static String username = "sa";
    private static String password = "sa";

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(dbUrl, username, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
