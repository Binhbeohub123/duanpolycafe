package Base64;

import java.util.Base64;

public class Base64Example {
    public String Hash(String Password){
        String encoded = Base64.getEncoder().encodeToString(Password.getBytes());
        return encoded;
    }
}     
