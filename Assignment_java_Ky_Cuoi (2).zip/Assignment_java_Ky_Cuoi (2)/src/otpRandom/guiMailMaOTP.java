package otpRandom;

import Base64.Base64Example;
import dao.DangkyDao;
import java.util.Properties;
import java.util.Random;
import java.util.HashMap;
import java.util.Map;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import dao.thaydoimatkhauDAO;
import giaodien.dangkyform;
import controller.DangKyController;

public class guiMailMaOTP {
    private static Map<String, String> otpStorage = new HashMap<>();
    private static Map<String, Long> otpTimestamps = new HashMap<>();
    private static final long OTP_EXPIRATION_TIME = 300000; // 5 phút (tính bằng milliseconds)
    private static dao.thaydoimatkhauDAO daodoimk = new thaydoimatkhauDAO();

    // Tạo mã OTP 6 chữ số
    public static String generateOTP() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

    // Lưu OTP với thời gian tạo
    public static void storeOTP(String email, String otp) {
        otpStorage.put(email, otp);
        otpTimestamps.put(email, System.currentTimeMillis());
    }

    // Xác thực OTP và trả về giá trị
    public static String verifyOTP(String email, String enteredOTP) {
        if (otpStorage.containsKey(email)) {
            String storedOTP = otpStorage.get(email);
            long creationTime = otpTimestamps.get(email);
            long currentTime = System.currentTimeMillis();

            if (currentTime - creationTime <= OTP_EXPIRATION_TIME) {
                if (enteredOTP.equals(storedOTP)) {
                    otpStorage.remove(email);
                    otpTimestamps.remove(email);
                    return storedOTP;
                } else {
                    return "OTP sai";
                }
            } else {
                otpStorage.remove(email);
                otpTimestamps.remove(email);
                return "OTP đã hết hạn";
            }
        } else {
            return "Không tìm thấy OTP cho email này";
        }
    }

    // Gửi OTP qua email
    public static boolean sendOTPEmail(String recipientEmail, String otp) {
        String from = "Binhnttv00241@gmail.com";
        String host = "smtp.gmail.com";
        String username = "Binhnttv00241@gmail.com";
        String password = "uleh ftnz trdw ahez";

        System.setProperty("https.protocols", "TLSv1.2");
        System.setProperty("mail.smtp.ssl.protocols", "TLSv1.2");
        Properties properties = System.getProperties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(username, password);
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipientEmail));
            message.setSubject("Mã OTP của bạn");

            MimeMultipart multipart = new MimeMultipart();
            MimeBodyPart textPart = new MimeBodyPart();
            textPart.setText("Mã OTP của bạn là: " + otp + "\nMã này có hiệu lực trong 5 phút. Vui lòng không chia sẻ mã này cho bất kỳ ai.");
            multipart.addBodyPart(textPart);

            message.setContent(multipart);
            Transport.send(message);
            return true;
        } catch (MessagingException mex) {
            mex.printStackTrace();
            return false;
        }
    }

    public static boolean guiEmailOTP(Component parent, String email) {
        if (email.isEmpty() || !email.contains("@")) {
            JOptionPane.showMessageDialog(parent, "Email không hợp lệ!");
            return false;
        }
        Base64Example hash = new Base64Example();
        String otp = hash.Hash(generateOTP());
        String PasswordDB = daodoimk.GetTenTaiKhoan(email);
        String password;
        if (PasswordDB != null) {
            password = hash.Hash(PasswordDB);
        } else {
            DangKyController controller = new DangKyController();
            PasswordDB = controller.getFullnameFromPending(email);
            password = hash.Hash(PasswordDB);
        }

        String combined = password + ":" + otp;
        storeOTP(email, combined);

        if (sendOTPEmail(email, combined)) {
            JOptionPane.showMessageDialog(parent, "Đã gửi OTP đến " + email);
            return true;
        } else {
            JOptionPane.showMessageDialog(parent, "Gửi OTP thất bại. Vui lòng kiểm tra cài đặt email.");
            return false;
        }
    }

    public static boolean xacNhanOTP(Component parent, String email, String enteredOTP) {
        String result = verifyOTP(email, enteredOTP);
        if (!result.equals("OTP sai") && !result.equals("OTP đã hết hạn") && !result.equals("Không tìm thấy OTP cho email này")) {
            JOptionPane.showMessageDialog(parent, "Xác thực OTP thành công!");
            return true;
        } else {
            JOptionPane.showMessageDialog(parent, result);
            return false;
        }
    }
}