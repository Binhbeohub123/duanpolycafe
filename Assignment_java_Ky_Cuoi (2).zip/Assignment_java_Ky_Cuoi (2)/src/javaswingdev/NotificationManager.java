package javaswingdev;

import java.awt.Frame;

public class NotificationManager {

    public static void showTopCenterNotification(Frame frame, String type, String message) {
        Notification.Type notificationType;
        switch (type.toUpperCase()) {
            case "SUCCESS":
                notificationType = Notification.Type.SUCCESS;
                break;
            case "INFO":
                notificationType = Notification.Type.INFO;
                break;
            case "WARNING":
                notificationType = Notification.Type.WARNING;
                break;
            default:
                throw new IllegalArgumentException("Loại thông báo không hợp lệ: " + type);
        }

        Notification notification = new Notification(frame, notificationType, Notification.Location.TOP_CENTER, message);
        notification.showNotification();
    }
}