/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import DBCONNEC.connectDBDangnhap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import poly.cafe.entity.PendingAccount;

/**
 *
 * @author acchi
 */
public class DangkyDao {
    public Boolean CheckUserExist(String Email) {
    String sql = "SELECT * FROM taikhoan WHERE Email = ?";
    try (Connection connection = connectDBDangnhap.getConnection();
         PreparedStatement ps = connection.prepareStatement(sql)) {
        if (connection == null) {
            throw new SQLException("Không thể kết nối đến cơ sở dữ liệu.");
        }
        ps.setString(1, Email);
        try (ResultSet rs = ps.executeQuery()) {
            return rs.next();
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi kiểm tra tài khoản: " + e.getMessage());
        e.printStackTrace();
        return false;
        }
    }
    public boolean Insert(String TaikhoanID, String MatKhau, String Email) {
    // Biến để lưu VTID
    String VTID;
    
    // Truy vấn đếm số lượng tài khoản trong bảng
    String countSql = "SELECT COUNT(*) AS total FROM taikhoan";
    // Truy vấn kiểm tra sự tồn tại của tài khoản theo Email
    String checkSql = "SELECT COUNT(*) AS total FROM taikhoan WHERE Email = ?";
    // Truy vấn chèn tài khoản mới
    String insertSql = "INSERT INTO taikhoan (TaikhoanID, Matkhau, Email, VTID) VALUES (?, ?, ?, ?)";
    
    try (Connection connection = connectDBDangnhap.getConnection()) {
        if (connection == null) {
            throw new SQLException("Không thể kết nối đến cơ sở dữ liệu.");
        }
        
        // Đếm số lượng tài khoản để gán VTID
        try (PreparedStatement countPs = connection.prepareStatement(countSql);
             ResultSet countRs = countPs.executeQuery()) {
            if (countRs.next()) {
                int totalAccounts = countRs.getInt("total");
                // Gán VTID: "000" nếu là tài khoản đầu tiên, "002" nếu là tài khoản thứ hai trở đi
                VTID = (totalAccounts == 0) ? "000" : "002";
            } else {
                throw new SQLException("Không thể đếm số lượng tài khoản.");
            }
        }
        
        // Kiểm tra xem email đã tồn tại chưa
        try (PreparedStatement checkPs = connection.prepareStatement(checkSql)) {
            checkPs.setString(1, Email);
            try (ResultSet rs = checkPs.executeQuery()) {
                if (rs.next()) {
                    int emailCount = rs.getInt("total");
                    if (emailCount > 0) {
                        // Email đã tồn tại, không insert
                        return true;
                    }
                }
            }
        }
        
        // Nếu email chưa tồn tại, thực hiện insert
        try (PreparedStatement insertPs = connection.prepareStatement(insertSql)) {
            insertPs.setString(1, TaikhoanID);
            insertPs.setString(2, MatKhau);
            insertPs.setString(3, Email);
            insertPs.setString(4, VTID);
            int rowsAffected = insertPs.executeUpdate();
            if (rowsAffected > 0) {
                // Insert thành công, gán VTID vào role
                return true;
            }
            return false;
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi kiểm tra hoặc chèn tài khoản: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}
    public static void insertPending(PendingAccount acc) {
    String sql = "INSERT INTO PendingAccount (taikhoanID, password, confirmPassword, email) VALUES (?, ?, ?, ?)";
    try (Connection conn = connectDBDangnhap.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, acc.getTaikhoanID());
        ps.setString(2, acc.getPassword());
        ps.setString(3, acc.getConfirmPassword());
        ps.setString(4, acc.getEmail());
        ps.executeUpdate();

    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    public static String getTenByEmail(String email) {
    String sql = "SELECT taikhoanID FROM PendingAccount WHERE email = ?";
    try (Connection conn = connectDBDangnhap.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getString("taikhoanID");
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

    public static PendingAccount findByEmail(String email) {
    String sql = "SELECT * FROM PendingAccount WHERE email = ?";
    try (Connection conn = connectDBDangnhap.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return new PendingAccount(
                rs.getString("taikhoanID"),
                rs.getString("password"),
                rs.getString("confirmPassword"),
                rs.getString("email")
            );
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

    public static void deleteByEmail(String email) {
    String sql = "DELETE FROM PendingAccount WHERE email = ?";
    try (Connection conn = connectDBDangnhap.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ps.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
    public static boolean confirmAndInsertAccount(String email) {
    // Lấy account tạm từ bảng PendingAccount
    PendingAccount acc = findByEmail(email);
    if (acc == null) {
        System.err.println("Không tìm thấy tài khoản tạm thời với email: " + email);
        return false;
    }

    // Kiểm tra nếu tài khoản đã tồn tại trong bảng chính thì không insert nữa
    if (new DangkyDao().CheckUserExist(email)) {
        System.err.println("Tài khoản với email đã tồn tại: " + email);
        return false;
    }

    // Insert vào bảng chính
    boolean inserted = new DangkyDao().Insert(
        acc.getTaikhoanID(),
        acc.getPassword(),
        acc.getEmail()
    );

    // Nếu insert thành công, xóa tài khoản tạm
    if (inserted) {
        deleteByEmail(email);
        return true;
    }

    return false;
}
}
