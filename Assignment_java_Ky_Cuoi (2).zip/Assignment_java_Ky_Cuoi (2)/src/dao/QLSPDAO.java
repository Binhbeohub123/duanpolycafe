package dao;

import DBCONNEC.DBConnection;
import poly.cafe.entity.QLSPmd;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QLSPDAO {
    private Connection conn;

    public QLSPDAO() {
        conn = DBConnection.getConnection(); // Nhớ có class DBConnection để get conn
    }

    public List<QLSPmd> getAllSanPham() {
        List<QLSPmd> list = new ArrayList<>();
        String sql = "SELECT * FROM QLSP";

        try (PreparedStatement pst = conn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                QLSPmd sp = new QLSPmd(
                    rs.getString("MASP"),
                    rs.getString("TENSP"),
                    rs.getString("LOAISP"),
                    rs.getDouble("GIA")
                );
                list.add(sp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int insert(QLSPmd sp) {
        String sql = "INSERT INTO QLSP (MASP, TENSP, LOAISP, GIA) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, sp.getMASP());
            pst.setString(2, sp.getTENSP());
            pst.setString(3, sp.getLOAISP());
            pst.setDouble(4, sp.getGIA());
            return pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int update(QLSPmd sp) {
        String sql = "UPDATE QLSP SET TENSP=?, LOAISP=?, GIA=? WHERE MASP=?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, sp.getTENSP());
            pst.setString(2, sp.getLOAISP());
            pst.setDouble(3, sp.getGIA());
            pst.setString(4, sp.getMASP());
            return pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int delete(String maSP) {
        String sql = "DELETE FROM QLSP WHERE MASP=?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, maSP);
            return pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public String getMaxMaSP() {
    String sql = "SELECT MAX(MASP) AS MaxMa FROM QLSP";
    try (PreparedStatement pst = conn.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {
        if (rs.next()) {
            return rs.getString("MaxMa");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
}
