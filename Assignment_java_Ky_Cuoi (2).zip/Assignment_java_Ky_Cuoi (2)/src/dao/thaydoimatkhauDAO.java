
package dao;

import DBCONNEC.connectDBDangnhap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class thaydoimatkhauDAO {
    // Check if user exists and get their role
    public boolean checkUserCredentials(String email) {
        String sql = "SELECT * FROM taikhoan WHERE Email = ? ";
        
        try (Connection connection = connectDBDangnhap.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
                return false;
            }
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next(); // Returns true if user exists with these credentials
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi kiểm tra thông tin đăng nhập: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public String GetTenTaiKhoan(String email){
        String sql = "SELECT TaiKhoanID FROM taikhoan WHERE Email = ?";
        String tentaikhoan = null;
        
        try (Connection connection = connectDBDangnhap.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
                return null;
            }
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    tentaikhoan = rs.getString("TaiKhoanID");
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi truy vấn vai trò: " + e.getMessage());
            e.printStackTrace();
        }
        return tentaikhoan;
    }

    // Update password
    public boolean updatePassword(String email, String newPassword) {
        String sql = "UPDATE taikhoan SET MatKhau = ? WHERE Email = ?";
        
        try (Connection connection = connectDBDangnhap.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
                return false;
            }
            ps.setString(1, newPassword);
            ps.setString(2, email);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Lỗi khi cập nhật mật khẩu: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
