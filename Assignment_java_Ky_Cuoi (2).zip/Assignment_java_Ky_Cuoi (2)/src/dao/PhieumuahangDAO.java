 
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import DBCONNEC.Connect;
import javax.swing.JOptionPane;
import poly.cafe.entity.Sanpham;
 
public class PhieumuahangDAO {
  public static List<Sanpham> getAll() {
        String sql = "SELECT MASP, TENSP, LOAISP, GIA FROM QLSP";
        List<Sanpham> list = new ArrayList<>();
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
                return list;
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Sanpham sp = new Sanpham();
                    sp.setMASP(rs.getString("MASP"));
                    sp.setTENSP(rs.getString("TENSP"));
                    sp.setLOAISP(rs.getString("LOAISP"));
                    sp.setGIA(rs.getDouble("GIA"));
                    list.add(sp);
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách sản phẩm: " + e.getMessage());
            e.printStackTrace();
        }
        return list;
    }

  public Sanpham findByten(String tenSP) {
        String sql = "SELECT MASP, TENSP, LOAISP, GIA FROM QLSP WHERE TENSP LIKE ?";
        Sanpham sp = null;
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return null;
            }
            ps.setString(1, "%" + tenSP + "%");
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    sp = new Sanpham();
                    sp.setMASP(rs.getString("MASP"));
                    sp.setTENSP(rs.getString("TENSP"));
                    sp.setLOAISP(rs.getString("LOAISP"));
                    sp.setGIA(rs.getDouble("GIA"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi tìm sản phẩm theo tên: " + e.getMessage());
            e.printStackTrace();
        }
        return sp;
    }

    public int insertPhieu(String maHD, String ngayLap, String tenNV, double phiPhuThu, String ghiChu, double tongTien) {
        String sql = "INSERT INTO PHIEUMUAHANG (MaHD, NgayLap, TenNV, PhiPhuThu, GhiChu, TongTien) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return 0;
            }
            ps.setString(1, maHD);
            ps.setString(2, ngayLap);
            ps.setString(3, tenNV);
            ps.setDouble(4, phiPhuThu);
            ps.setString(5, ghiChu);
            ps.setDouble(6, tongTien);
            return ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi thêm phiếu mua hàng: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }

    public int insertChiTietPhieu(String maHD, String maSP, int soLuong, double gia) {
        String sql = "INSERT INTO CHITIETPHIEU (MaHD, MaSP, SoLuong, Gia) VALUES (?, ?, ?, ?)";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return 0;
            }
            ps.setString(1, maHD);
            ps.setString(2, maSP);
            ps.setInt(3, soLuong);
            ps.setDouble(4, gia);
            return ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi thêm chi tiết phiếu: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }

    public int insert(Sanpham sp) {
        String sql = "INSERT INTO QLSP (MASP, TENSP, LOAISP, GIA) VALUES (?, ?, ?, ?)";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return 0;
            }
            ps.setString(1, sp.getMASP());
            ps.setString(2, sp.getTENSP());
            ps.setString(3, sp.getLOAISP());
            ps.setDouble(4, sp.getGIA());
            return ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi thêm sản phẩm: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }

    public int update(Sanpham sp) {
        String sql = "UPDATE QLSP SET TENSP = ?, LOAISP = ?, GIA = ? WHERE MASP = ?";
        try (Connection connection = Connect.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Không thể kết nối đến cơ sở dữ liệu.");
                return 0;
            }
            ps.setString(1, sp.getTENSP());
            ps.setString(2, sp.getLOAISP());
            ps.setDouble(3, sp.getGIA());
            ps.setString(4, sp.getMASP());
            return ps.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi cập nhật sản phẩm: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
}