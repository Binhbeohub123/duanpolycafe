package Theme;

import java.awt.Color;
import java.awt.Font;
import javax.swing.UIManager;

public class UITheme {
    public static void apply() {
        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.PLAIN, 16));
        UIManager.put("OptionPane.buttonFont", new Font("Arial", Font.BOLD, 14));
        UIManager.put("OptionPane.background", new Color(240, 240, 240));
        UIManager.put("Button.background", Color.WHITE);
    }
}