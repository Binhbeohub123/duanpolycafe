package giaodien;

import controller.QLNVController;
import java.awt.Image;
import java.io.File;
import java.util.List;
import poly.cafe.entity.QLNV;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.MediaTracker;

public class QLNV extends javax.swing.JPanel {
 private QLNVController controller = new QLNVController();
    private List<QLNV> listNV;

    public QLNV() {
        initComponents();
         loadDatabase();  
        initEvent();
    }
     private void initEvent() {
    table.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
            ShowDetail();
        }
    });
    }

    public void loadDatabase() {
        listNV = controller.layDanhSachNhanVien(); // gọi Controller lấy dữ liệu
        String[] title = {"Họ Tên", "Ngày Sinh", "SDT", "Giới Tính"};
        DefaultTableModel dtb = new DefaultTableModel(title, 0);
        for (QLNV nv : listNV) {
            dtb.addRow(new Object[]{
                nv.getTenNV(),
                nv.getNgaySinh(),
                nv.getSdt(),
                nv.getGioiTinh()
            });
        }
        table.setModel(dtb);
    }

    public QLNV getForm() {
        String hoTen = txtHoTen.getText();
        String sdt = txtSDT.getText();
       String ngaySinhText = txtNgaySinh.getText().trim();
        String gioiTinh = rdoNam.isSelected() ? "Nam" : "Nữ";

        if (hoTen.isEmpty() || sdt.isEmpty() || ngaySinhText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin.");
            return null;
        }

        try {
            java.sql.Date ngaySinh = java.sql.Date.valueOf(ngaySinhText);
            return new QLNV(0, hoTen, gioiTinh, ngaySinh, sdt);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Ngày sinh không đúng định dạng (yyyy-MM-dd).");
            return null;
        }
    }
public void ShowDetail() {
    int index = this.table.getSelectedRow();
    
    QLNV nv = listNV.get(index);
    this.txtHoTen.setText(nv.getTenNV());
    this.txtNgaySinh.setText(nv.getNgaySinh().toString());
    if (nv.getGioiTinh().equalsIgnoreCase("Nam")) {
        rdoNam.setSelected(true);
        rdo_Nu.setSelected(false);
    } else {
        rdoNam.setSelected(false);
        rdo_Nu.setSelected(true);
    }
    this.txtSDT.setText(nv.getSdt());

    // Hiển thị ảnh trên lblImage2
    String path = nv.getHinhanh();
    if (path != null && !path.isEmpty()) {
        ImageIcon icon = new ImageIcon(path);
        if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
            int width = lblImage2.getWidth() > 0 ? lblImage2.getWidth() : 200;
            int height = lblImage2.getHeight() > 0 ? lblImage2.getHeight() : 200;
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            lblImage2.setIcon(new ImageIcon(img));
            lblImage2.revalidate();
            lblImage2.repaint();
        } else {
            JOptionPane.showMessageDialog(this, "Không thể tải ảnh từ: " + path);
            lblImage2.setIcon(null);
        }
    } else {
        lblImage2.setIcon(null);
    }
}

public void chonAnh(QLNV nv) {
    JFileChooser fileChooser = new JFileChooser();
    int ret = fileChooser.showOpenDialog(this);
    if (ret == JFileChooser.APPROVE_OPTION) {
        File file = fileChooser.getSelectedFile();
        if (file.exists() && file.canRead()) {
            String path = file.getAbsolutePath();

            ImageIcon icon = new ImageIcon(path);
            if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
                int width = lblImage2.getWidth() > 0 ? lblImage2.getWidth() : 200; // Sử dụng lblImage2
                int height = lblImage2.getHeight() > 0 ? lblImage2.getHeight() : 200;
                Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                lblImage2.setIcon(new ImageIcon(img)); // Gán vào lblImage2
                lblImage2.revalidate();
                lblImage2.repaint();

                nv.setHinhanh(path);
            } else {
                JOptionPane.showMessageDialog(this, "Không thể tải ảnh: " + path);
            }
        } else {
            JOptionPane.showMessageDialog(this, "File không tồn tại hoặc không thể đọc.");
        }
    }
}
public void timKiemNV() {
    String keyword = txt_TimTenNV.getText().trim();

    if (keyword.isEmpty()) {
        listNV = controller.layDanhSachNhanVien(); 
    } else {
        listNV = controller.timKiemNhanVien(keyword);
        JOptionPane.showMessageDialog(this,"không có trong danh sách ");
    }

    String[] title = {"Họ Tên", "Ngày Sinh", "SDT", "Giới Tính"};
    DefaultTableModel dtb = new DefaultTableModel(title, 0);

    for (QLNV nv : listNV) {
        dtb.addRow(new Object[]{
            nv.getTenNV(),
            nv.getNgaySinh(),
            nv.getSdt(),
            nv.getGioiTinh()
        });
    }
    table.setModel(dtb);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        txt_TimTenNV = new javax.swing.JTextField();
        btnsr = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtNgaySinh = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtHoTen = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtSDT = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        btndeleteimg = new javax.swing.JButton();
        btnimage = new javax.swing.JButton();
        panel = new javax.swing.JPanel();
        lblImage2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        rdoNam = new javax.swing.JRadioButton();
        rdo_Nu = new javax.swing.JRadioButton();
        btnDelete = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();

        setBackground(new java.awt.Color(176, 236, 188));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(176, 236, 188));

        txt_TimTenNV.setText("Tìm kiếm .....");
        txt_TimTenNV.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txt_TimTenNV.setCaretColor(new java.awt.Color(204, 204, 204));

        btnsr.setBackground(new java.awt.Color(0, 0, 0));
        btnsr.setForeground(new java.awt.Color(255, 255, 255));
        btnsr.setText("Tìm kiếm");
        btnsr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsrActionPerformed(evt);
            }
        });

        table.setBackground(new java.awt.Color(176, 236, 188));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Họ Tên ", "Ngày Sinh ", "SDT ", "Giới Tính "
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1061, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 19, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(txt_TimTenNV)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnsr)
                .addGap(29, 29, 29))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_TimTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsr, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 661, Short.MAX_VALUE)
                .addContainerGap())
        );

        add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 1080, 710));

        jPanel3.setBackground(new java.awt.Color(176, 236, 188));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Ngày Sinh Nhân Viên");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 480, -1, -1));

        txtNgaySinh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNgaySinhActionPerformed(evt);
            }
        });
        jPanel3.add(txtNgaySinh, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 260, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Tên Nhân Viên");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, -1, -1));

        txtHoTen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoTenActionPerformed(evt);
            }
        });
        jPanel3.add(txtHoTen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 260, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Số Điện Thoại");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 560, -1, -1));

        txtSDT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSDTActionPerformed(evt);
            }
        });
        jPanel3.add(txtSDT, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 590, 260, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Giới Tính");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 640, -1, -1));

        btndeleteimg.setText("Xóa ảnh");
        btndeleteimg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteimgActionPerformed(evt);
            }
        });
        jPanel3.add(btndeleteimg, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 330, -1, -1));

        btnimage.setText("Thêm ảnh");
        btnimage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnimageActionPerformed(evt);
            }
        });
        jPanel3.add(btnimage, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, -1, -1));

        panel.setBackground(new java.awt.Color(204, 255, 204));
        panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblImage2, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblImage2, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.add(panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, 190));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setText("Thông Tin");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, -1));

        rdoNam.setText("Nam");
        rdoNam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoNamActionPerformed(evt);
            }
        });
        jPanel3.add(rdoNam, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 690, -1, -1));

        rdo_Nu.setText("Nu");
        jPanel3.add(rdo_Nu, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 690, -1, -1));

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 0, 300, 730));

        btnDelete.setText("Xóa");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 740, -1, -1));

        jButton1.setText("Thêm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 740, -1, -1));

        btnupdate.setText("Cập nhật");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        add(btnupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 740, -1, -1));

        jButton7.setText("Xuất PDF");
        add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 740, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void txtNgaySinhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNgaySinhActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNgaySinhActionPerformed

    private void txtHoTenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoTenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoTenActionPerformed

    private void txtSDTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSDTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSDTActionPerformed

    private void btnimageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnimageActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        int index = table.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên để thêm ảnh.");
            return;
        }
        QLNV nv = listNV.get(index);
        chonAnh(nv);

        if (controller.capNhatNhanVien(nv)) {
            JOptionPane.showMessageDialog(this, "Cập nhật ảnh thành công.");
            loadDatabase();
        } else {
            JOptionPane.showMessageDialog(this, "Cập nhật ảnh thất bại.");
        }
    }//GEN-LAST:event_btnimageActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
        ShowDetail();
    }//GEN-LAST:event_tableMouseClicked

    private void rdoNamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoNamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdoNamActionPerformed

    private void btnsrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsrActionPerformed
        // TODO add your handling code here:
        timKiemNV();
    }//GEN-LAST:event_btnsrActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
         int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên cần xóa");
            return;
        }
        int ret = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa không?", "Xóa", JOptionPane.YES_NO_OPTION);
        if (ret == JOptionPane.YES_OPTION) {
            int maNV = listNV.get(row).getMaNV();
            if (controller.xoaNhanVien(maNV)) {
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                loadDatabase();
            } else {
                JOptionPane.showMessageDialog(this, "Xóa thất bại");
            }
        }
        
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btndeleteimgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteimgActionPerformed
        // TODO add your handling code here:
         int index = table.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên để xóa ảnh.");
            return;
        }
        QLNV nv = listNV.get(index);
        nv.setHinhanh(null);   // Xóa đường dẫn ảnh trong dữ liệu
        lblImage2.setIcon(null); // Xóa ảnh trên giao diện
        JOptionPane.showMessageDialog(this, "Đã xóa ảnh nhân viên.");
    }//GEN-LAST:event_btndeleteimgActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        // TODO add your handling code here:
         int index = table.getSelectedRow();

        QLNV newNV = getForm();
        if (newNV == null) {
            return;
        }
        int maNV = listNV.get(index).getMaNV();
        newNV.setMaNV(maNV);

        boolean result = controller.capNhatNhanVien(newNV);
        if (result) {
            JOptionPane.showMessageDialog(this, "Cập nhật thành công.");
            loadDatabase();
        } else {
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại.");
        }
    }//GEN-LAST:event_btnupdateActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         int ret = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thêm?", "Thêm", JOptionPane.YES_NO_OPTION);
        if (ret == JOptionPane.YES_OPTION) {
            QLNV nv = getForm();
            if (nv != null) {
                if (controller.themNhanVien(nv)) {
                    JOptionPane.showMessageDialog(this, "Thêm thành công");
                    loadDatabase();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại");
                }
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btndeleteimg;
    private javax.swing.JButton btnimage;
    private javax.swing.JButton btnsr;
    private javax.swing.JButton btnupdate;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblImage2;
    private javax.swing.JPanel panel;
    private javax.swing.JRadioButton rdoNam;
    private javax.swing.JRadioButton rdo_Nu;
    private javax.swing.JTable table;
    private javax.swing.JTextField txtHoTen;
    private javax.swing.JTextField txtNgaySinh;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txt_TimTenNV;
    // End of variables declaration//GEN-END:variables
}
