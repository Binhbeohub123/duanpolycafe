
package giaodien;


import controller.Controller;
import poly.cafe.entity.Model;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author ADMIN
 */
public class quanlythe extends javax.swing.JFrame {
private PhieuMuaHang phieuMuaHang; // Biến để lưu tham chiếu đến PhieuMuaHang

    // Constructor nhận tham chiếu PhieuMuaHang
    public quanlythe(PhieuMuaHang phieuMuaHang) {
        this.phieuMuaHang = phieuMuaHang; // Lưu tham chiếu
        initComponents();
        loadTable();
    }

    private void loadTable() {
        Controller controller = new Controller();
        List<Model> list = controller.getAllThe();

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Xóa toàn bộ dòng cũ

        for (Model item : list) {
            Object[] row = {
                item.isTrangthai(), // true = Đang sử dụng, false = Đang trống
                item.getMathe()
            };
            model.addRow(row);
        }
    }


  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        btnthem = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Quản lý thẻ");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                { new Boolean(false), ""},
                {null, ""},
                {null, ""},
                {null, ""},
                {null, ""},
                {null, ""},
                {null, ""},
                {null, ""},
                {null, ""}
            },
            new String [] {
                "Trạng thái", "Mã thẻ"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Boolean.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(80);
            jTable1.getColumnModel().getColumn(0).setMaxWidth(80);
        }

        jButton1.setText("Cập nhật");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnthem.setText("thêm");
        btnthem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnthemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnthem)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jButton1)
                    .addComponent(btnthem))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    Controller controller = new Controller();
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    boolean updated = false;

    for (int i = 0; i < model.getRowCount(); i++) {
        Object oTrangthai = model.getValueAt(i, 0);
        Object oMathe = model.getValueAt(i, 1);

        if (oMathe == null || oMathe.toString().trim().isEmpty()) {
            continue; // Bỏ qua nếu mã thẻ rỗng
        }

        // Kiểm tra và lấy trạng thái từ ô checkbox
        boolean trangthai = false; // Mặc định là false
        if (oTrangthai instanceof Boolean) {
            trangthai = (Boolean) oTrangthai;
        } else {
            JOptionPane.showMessageDialog(this, "Trạng thái không hợp lệ ở dòng " + (i + 1) + "!");
            return;
        }

        String mathe = oMathe.toString().trim();

        // Kiểm tra xem trạng thái có thay đổi so với dữ liệu trong cơ sở dữ liệu không
        Model currentThe = controller.getTheByMaThe(mathe); 
        if (currentThe != null && currentThe.isTrangthai() != trangthai) {
            Model the = new Model(trangthai, mathe);
            boolean success = controller.capNhatThe(the);
            if (!success) {
                JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật trạng thái thẻ " + mathe + "!");
                return;
            }
            updated = true;
        }
    }

    // Tải lại bảng để phản ánh trạng thái mới
    loadTable();

    if (updated) {
        JOptionPane.showMessageDialog(this, "Cập nhật trạng thái thẻ thành công!");
    } else {
        JOptionPane.showMessageDialog(this, "Không có thay đổi nào được cập nhật!");
    }
    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnthemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnthemActionPerformed
       int selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một thẻ từ bảng!");
        return;
    }

    // Lấy trạng thái và mã thẻ từ dòng được chọn
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    boolean trangthai = (Boolean) model.getValueAt(selectedRow, 0);
    String maThe = model.getValueAt(selectedRow, 1).toString().trim();

    // Kiểm tra trạng thái thẻ
    if (trangthai) {
        JOptionPane.showMessageDialog(this, "Thẻ " + maThe + " đang được sử dụng, vui lòng chọn thẻ khác!");
        return;
    }

    // Nếu đã có thẻ cũ được chọn trong PhieuMuaHang, đặt lại trạng thái thẻ cũ
    if (phieuMuaHang != null && phieuMuaHang.getSelectedMaThe() != null && !phieuMuaHang.getSelectedMaThe().isEmpty()) {
        String oldMaThe = phieuMuaHang.getSelectedMaThe();
        if (!oldMaThe.equals(maThe)) { // Chỉ đặt lại nếu thẻ cũ khác thẻ mới
            Controller controller = new Controller();
            Model oldThe = new Model(false, oldMaThe);
            boolean resetSuccess = controller.capNhatThe(oldThe);
            if (!resetSuccess) {
                JOptionPane.showMessageDialog(this, "Lỗi khi đặt lại trạng thái thẻ cũ " + oldMaThe + "!");
                return;
            }
        }
    }

    // Cập nhật trạng thái thẻ mới thành "đang sử dụng" (true)
    Controller controller = new Controller();
    Model the = new Model(true, maThe);
    boolean updated = controller.capNhatThe(the);
    if (!updated) {
        JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật trạng thái thẻ!");
        return;
    }

    // Gửi mã thẻ sang PhieuMuaHang
    if (phieuMuaHang != null) {
        phieuMuaHang.setSelectedMaThe(maThe);
        phieuMuaHang.updateBtnChooseText(maThe);
    }

    // Tải lại bảng để hiển thị trạng thái mới
    loadTable();

    // Đóng cửa sổ quanlythe
    this.dispose();
    }//GEN-LAST:event_btnthemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(quanlythe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(quanlythe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(quanlythe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(quanlythe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
       java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                // Không khởi tạo PhieuMuaHang ở đây, sẽ được truyền từ bên ngoài
                new quanlythe(null).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnthem;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
